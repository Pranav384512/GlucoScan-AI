/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect, ChangeEvent } from 'react';
import { 
  Upload, 
  Eye, 
  Activity, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight, 
  Info,
  RefreshCw,
  Image as ImageIcon,
  Zap,
  FileText,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { processGlaucomaImage, AnalysisResult } from './utils/imageProcessing';
import { generatePDFReport } from './utils/reportGenerator';

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCvLoaded, setIsCvLoaded] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkCv = setInterval(() => {
      // @ts-ignore
      if (window.cv && window.cv.Mat) {
        setIsCvLoaded(true);
        clearInterval(checkCv);
      }
    }, 500);
    return () => clearInterval(checkCv);
  }, []);

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImage(event.target?.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const runAnalysis = async () => {
    if (!image) return;
    setIsProcessing(true);
    setError(null);

    try {
      const img = new Image();
      img.src = image;
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });

      const analysisResult = await processGlaucomaImage(img);
      setResult(analysisResult);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An error occurred during image processing.');
    } finally {
      setIsProcessing(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <Eye className="text-white w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">GlaucoScan <span className="text-indigo-600">AI</span></h1>
          </div>
          <div className="flex items-center gap-4">
            {!isCvLoaded && (
              <div className="flex items-center gap-2 text-xs font-medium text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
                <RefreshCw className="w-3 h-3 animate-spin" />
                Initializing Engine...
              </div>
            )}
            {isCvLoaded && (
              <div className="flex items-center gap-2 text-xs font-medium text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                Engine Ready
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Upload & Controls */}
          <div className="lg:col-span-4 space-y-6">
            <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Input Image
              </h2>
              
              {!image ? (
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-200 rounded-xl p-8 flex flex-col items-center justify-center gap-4 hover:border-indigo-400 hover:bg-indigo-50/30 transition-all cursor-pointer group"
                >
                  <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                    <ImageIcon className="text-slate-400 group-hover:text-indigo-500 w-6 h-6" />
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-slate-700">Click to upload fundus image</p>
                    <p className="text-xs text-slate-400 mt-1">Supports JPG, PNG (Max 10MB)</p>
                  </div>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden" 
                    accept="image/*"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative aspect-square rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
                    <img src={image} alt="Preview" className="w-full h-full object-cover" />
                    <button 
                      onClick={reset}
                      className="absolute top-2 right-2 p-2 bg-white/90 backdrop-blur shadow-sm rounded-full hover:bg-white transition-colors"
                    >
                      <RefreshCw className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>
                  <button 
                    onClick={runAnalysis}
                    disabled={isProcessing || !isCvLoaded}
                    className="w-full py-3 bg-indigo-600 text-white rounded-xl font-semibold shadow-lg shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:shadow-none transition-all flex items-center justify-center gap-2"
                  >
                    {isProcessing ? (
                      <>
                        <RefreshCw className="w-5 h-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Zap className="w-5 h-5 fill-current" />
                        Run Analysis
                      </>
                    )}
                  </button>
                </div>
              )}
            </section>

            <section className="bg-indigo-900 rounded-2xl p-6 text-white overflow-hidden relative">
              <div className="relative z-10">
                <h3 className="font-bold text-lg mb-2">How it works</h3>
                <ul className="space-y-3 text-indigo-100 text-sm">
                  <li className="flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-700 flex items-center justify-center text-[10px] font-bold shrink-0">01</span>
                    <span>Extracts the green channel for optimal contrast of the optic disc.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-700 flex items-center justify-center text-[10px] font-bold shrink-0">02</span>
                    <span>Applies CLAHE and median blur to enhance features and reduce noise.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-700 flex items-center justify-center text-[10px] font-bold shrink-0">03</span>
                    <span>Segments the optic disc (red) and cup (blue) using percentile thresholding.</span>
                  </li>
                  <li className="flex gap-3">
                    <span className="w-5 h-5 rounded-full bg-indigo-700 flex items-center justify-center text-[10px] font-bold shrink-0">04</span>
                    <span>Calculates the vertical Cup-to-Disc Ratio (CDR) for diagnosis.</span>
                  </li>
                </ul>
              </div>
              <Activity className="absolute -bottom-8 -right-8 w-32 h-32 text-indigo-800/50 rotate-12" />
            </section>
          </div>

          {/* Right Column: Results */}
          <div className="lg:col-span-8">
            <AnimatePresence mode="wait">
              {!result && !isProcessing && !error && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="h-full min-h-[400px] bg-white rounded-2xl border border-slate-200 border-dashed flex flex-col items-center justify-center p-12 text-center"
                >
                  <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                    <Activity className="text-slate-300 w-10 h-10" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Ready for Analysis</h3>
                  <p className="text-slate-500 max-w-md mx-auto">
                    Upload a high-quality retinal fundus image to begin the automated glaucoma screening process.
                  </p>
                </motion.div>
              )}

              {isProcessing && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="h-full min-h-[400px] bg-white rounded-2xl border border-slate-200 flex flex-col items-center justify-center p-12"
                >
                  <div className="relative w-24 h-24 mb-8">
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      className="absolute inset-0 border-4 border-indigo-100 border-t-indigo-600 rounded-full"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Eye className="text-indigo-600 w-8 h-8" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">Analyzing Retinal Features</h3>
                  <div className="flex flex-col gap-2 w-full max-w-xs">
                    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ x: ["-100%", "100%"] }}
                        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                        className="h-full w-1/2 bg-indigo-600 rounded-full"
                      />
                    </div>
                    <p className="text-xs text-slate-400 text-center font-mono uppercase tracking-widest">Processing ROI & Segmentation</p>
                  </div>
                </motion.div>
              )}

              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="h-full min-h-[400px] bg-red-50 rounded-2xl border border-red-100 flex flex-col items-center justify-center p-12 text-center"
                >
                  <AlertCircle className="text-red-500 w-16 h-16 mb-4" />
                  <h3 className="text-xl font-bold text-red-800 mb-2">Analysis Failed</h3>
                  <p className="text-red-600 max-w-md mx-auto mb-6">{error}</p>
                  <button 
                    onClick={reset}
                    className="px-6 py-2 bg-white text-red-600 border border-red-200 rounded-lg font-semibold hover:bg-red-100 transition-colors"
                  >
                    Try Again
                  </button>
                </motion.div>
              )}

              {result && (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  {/* Result Header Card */}
                  <div className={`p-6 rounded-2xl border flex items-center justify-between ${
                    result.isGlaucoma 
                      ? 'bg-red-50 border-red-100 text-red-900' 
                      : 'bg-emerald-50 border-emerald-100 text-emerald-900'
                  }`}>
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        result.isGlaucoma ? 'bg-red-500' : 'bg-emerald-500'
                      }`}>
                        {result.isGlaucoma ? <AlertCircle className="text-white w-7 h-7" /> : <CheckCircle2 className="text-white w-7 h-7" />}
                      </div>
                      <div>
                        <p className="text-xs font-bold uppercase tracking-widest opacity-70">Diagnostic Result</p>
                        <h3 className="text-2xl font-black tracking-tight">{result.diagnosis}</h3>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end gap-2">
                      <div>
                        <p className="text-xs font-bold uppercase tracking-widest opacity-70">Vertical CDR</p>
                        <p className="text-3xl font-black font-mono">{result.cdr.toFixed(3)}</p>
                      </div>
                      <button 
                        onClick={() => generatePDFReport(result)}
                        className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur hover:bg-white/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors border border-white/20"
                      >
                        <FileText className="w-4 h-4" />
                        Download Report
                      </button>
                    </div>
                  </div>

                  {/* Visualizations Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preprocessed ROI</h4>
                        <Info className="w-3 h-3 text-slate-300" />
                      </div>
                      <div className="aspect-square rounded-xl overflow-hidden bg-slate-900 border border-slate-200">
                        <img src={result.roiUrl} alt="ROI" className="w-full h-full object-contain" />
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight italic">
                        Green channel extraction with CLAHE enhancement for feature isolation.
                      </p>
                    </div>

                    <div className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Segmentation Overlay</h4>
                        <div className="flex gap-2">
                          <span className="flex items-center gap-1 text-[10px] font-bold text-red-500"><span className="w-2 h-2 bg-red-500 rounded-full"></span> Disc</span>
                          <span className="flex items-center gap-1 text-[10px] font-bold text-blue-500"><span className="w-2 h-2 bg-blue-500 rounded-full"></span> Cup</span>
                        </div>
                      </div>
                      <div className="aspect-square rounded-xl overflow-hidden bg-slate-900 border border-slate-200">
                        <img src={result.resultUrl} alt="Result" className="w-full h-full object-contain" />
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight italic">
                        Automated contour detection of the optic disc and cup boundaries.
                      </p>
                    </div>
                  </div>

                  {/* Detailed Stats */}
                  <div className="bg-white rounded-2xl border border-slate-200 p-6">
                    <h4 className="text-sm font-bold text-slate-800 mb-4">Technical Parameters</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div className="p-3 bg-slate-50 rounded-xl">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Threshold P85</p>
                        <p className="text-lg font-bold text-slate-700">Disc Detection</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-xl">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Threshold P96</p>
                        <p className="text-lg font-bold text-slate-700">Cup Detection</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-xl">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">ROI Radius</p>
                        <p className="text-lg font-bold text-slate-700">450px</p>
                      </div>
                      <div className={`p-3 rounded-xl ${result.isGlaucoma ? 'bg-red-100' : 'bg-emerald-100'}`}>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Risk Level</p>
                        <p className={`text-lg font-bold ${result.isGlaucoma ? 'text-red-700' : 'text-emerald-700'}`}>
                          {result.isGlaucoma ? 'High' : 'Low'}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 border-t border-slate-200 mt-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400 text-xs">
          <p>© 2026 GlaucoScan AI. For research purposes only. Not a substitute for professional medical advice.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-indigo-600 transition-colors">Documentation</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Terms of Service</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
