/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { AnalysisResult } from './imageProcessing';

export async function generatePDFReport(result: AnalysisResult) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  let currentY = 20;

  // Header
  doc.setFillColor(79, 70, 229); // Indigo-600
  doc.rect(0, 0, pageWidth, 40, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('GlaucoScan AI', margin, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Automated Glaucoma Screening Report', margin, 32);
  
  const date = new Date().toLocaleString();
  doc.text(`Date: ${date}`, pageWidth - margin - 50, 25);

  currentY = 55;

  // Diagnostic Summary
  doc.setTextColor(30, 41, 59); // Slate-800
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Diagnostic Summary', margin, currentY);
  currentY += 10;

  doc.setDrawColor(226, 232, 240); // Slate-200
  doc.line(margin, currentY - 5, pageWidth - margin, currentY - 5);

  doc.setFontSize(12);
  doc.text('Result:', margin, currentY);
  
  if (result.isGlaucoma) {
    doc.setTextColor(220, 38, 38); // Red-600
  } else {
    doc.setTextColor(5, 150, 105); // Emerald-600
  }
  doc.text(result.diagnosis, margin + 20, currentY);
  
  doc.setTextColor(30, 41, 59);
  doc.text('Vertical CDR:', margin + 100, currentY);
  doc.setFont('courier', 'bold');
  doc.text(result.cdr.toFixed(3), margin + 130, currentY);
  
  currentY += 15;

  // Visualizations
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('Visual Analysis', margin, currentY);
  currentY += 10;

  // ROI Image
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('Preprocessed ROI', margin, currentY);
  doc.text('Segmentation Overlay', margin + (pageWidth - 2 * margin) / 2 + 5, currentY);
  currentY += 5;

  const imgSize = (pageWidth - 2 * margin - 10) / 2;
  
  try {
    doc.addImage(result.roiUrl, 'PNG', margin, currentY, imgSize, imgSize);
    doc.addImage(result.resultUrl, 'PNG', margin + imgSize + 10, currentY, imgSize, imgSize);
  } catch (e) {
    console.error('Error adding images to PDF', e);
  }

  currentY += imgSize + 15;

  // Technical Parameters
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('Technical Parameters', margin, currentY);
  currentY += 10;

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  const params = [
    ['Parameter', 'Value'],
    ['Threshold P85 (Disc)', 'Active'],
    ['Threshold P96 (Cup)', 'Active'],
    ['ROI Radius', '450px'],
    ['Risk Level', result.isGlaucoma ? 'High' : 'Low'],
    ['Processing Engine', 'OpenCV.js (WASM)']
  ];

  params.forEach(([label, value], index) => {
    if (index === 0) doc.setFont('helvetica', 'bold');
    else doc.setFont('helvetica', 'normal');
    
    doc.text(label, margin, currentY);
    doc.text(value, margin + 60, currentY);
    currentY += 7;
  });

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(148, 163, 184); // Slate-400
  const footerText = 'This report is generated automatically for research purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment.';
  const splitFooter = doc.splitTextToSize(footerText, pageWidth - 2 * margin);
  doc.text(splitFooter, margin, doc.internal.pageSize.getHeight() - 15);

  doc.save(`GlaucoScan_Report_${new Date().getTime()}.pdf`);
}
