/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

declare const cv: any;

export interface AnalysisResult {
  originalUrl: string;
  roiUrl: string;
  resultUrl: string;
  cdr: number;
  diagnosis: string;
  isGlaucoma: boolean;
}

export async function processGlaucomaImage(imageElement: HTMLImageElement): Promise<AnalysisResult> {
  if (typeof cv === 'undefined') {
    throw new Error('OpenCV.js is not loaded yet.');
  }

  // 1. Load Image
  let src = cv.imread(imageElement);
  let rgb = new cv.Mat();
  cv.cvtColor(src, rgb, cv.COLOR_RGBA2RGB);

  // 2. Preprocess (Extracting the best features)
  let channels = new cv.MatVector();
  cv.split(rgb, channels);
  let green = channels.get(1);

  let blurred = new cv.Mat();
  cv.medianBlur(green, blurred, 7);

  let enhanced = new cv.Mat();
  let clahe = new cv.CLAHE(3.0, new cv.Size(8, 8));
  clahe.apply(blurred, enhanced);

  // 3. ROI EXTRACTION
  let minMax = cv.minMaxLoc(enhanced);
  let { maxLoc } = minMax;
  let r = 450;
  
  let xStart = Math.max(0, maxLoc.x - r);
  let yStart = Math.max(0, maxLoc.y - r);
  let xEnd = Math.min(enhanced.cols, maxLoc.x + r);
  let yEnd = Math.min(enhanced.rows, maxLoc.y + r);
  
  let rect = new cv.Rect(xStart, yStart, xEnd - xStart, yEnd - yStart);
  let roi = enhanced.roi(rect);
  let roiRgb = rgb.roi(rect);

  // 4. SEGMENTATION
  let kernel = cv.getStructuringElement(cv.MORPH_ELLIPSE, new cv.Size(25, 25));
  let noVessels = new cv.Mat();
  cv.morphologyEx(roi, noVessels, cv.MORPH_CLOSE, kernel);

  // Get data for percentile calculation
  let data = noVessels.data;
  const getPercentile = (arr: Uint8Array, p: number) => {
    const sorted = new Uint8Array(arr).sort();
    const index = Math.floor((p / 100) * (sorted.length - 1));
    return sorted[index];
  };

  let p85 = getPercentile(data, 85);
  let p96 = getPercentile(data, 96);

  let discBin = new cv.Mat();
  cv.threshold(noVessels, discBin, p85, 255, cv.THRESH_BINARY);

  let cupBin = new cv.Mat();
  cv.threshold(noVessels, cupBin, p96, 255, cv.THRESH_BINARY);

  // 5. VERTICAL CDR CALCULATION
  const getVerticalHeight = (binaryMask: any) => {
    let contours = new cv.MatVector();
    let hierarchy = new cv.Mat();
    cv.findContours(binaryMask, contours, hierarchy, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE);
    
    if (contours.size() === 0) {
      contours.delete();
      hierarchy.delete();
      return { height: 0, contour: null };
    }

    let maxArea = 0;
    let maxIdx = 0;
    for (let i = 0; i < contours.size(); ++i) {
      let area = cv.contourArea(contours.get(i));
      if (area > maxArea) {
        maxArea = area;
        maxIdx = i;
      }
    }

    let cnt = contours.get(maxIdx);
    let rect = cv.boundingRect(cnt);
    
    // We need to clone the contour before deleting the vector
    let resultContour = cnt.clone();
    
    contours.delete();
    hierarchy.delete();
    
    return { height: rect.height, contour: resultContour };
  };

  let { height: dH, contour: dCnt } = getVerticalHeight(discBin);
  let { height: cH, contour: cCnt } = getVerticalHeight(cupBin);

  let cdr = dH > 0 ? cH / dH : 0;
  let isGlaucoma = cdr > 0.65;
  let diagnosis = isGlaucoma ? "GLAUCOMA DETECTED" : "NORMAL EYE";

  // 6. DRAW OVERLAYS
  let resultMat = roiRgb.clone();
  if (dCnt) {
    let contours = new cv.MatVector();
    contours.push_back(dCnt);
    cv.drawContours(resultMat, contours, -1, new cv.Scalar(255, 0, 0), 3);
    contours.delete();
  }
  if (cCnt) {
    let contours = new cv.MatVector();
    contours.push_back(cCnt);
    cv.drawContours(resultMat, contours, -1, new cv.Scalar(0, 0, 255), 3);
    contours.delete();
  }

  // Convert Mats to Data URLs
  const matToUrl = (mat: any) => {
    let canvas = document.createElement('canvas');
    cv.imshow(canvas, mat);
    return canvas.toDataURL();
  };

  const result = {
    originalUrl: imageElement.src,
    roiUrl: matToUrl(roi),
    resultUrl: matToUrl(resultMat),
    cdr,
    diagnosis,
    isGlaucoma
  };

  // Cleanup
  src.delete(); rgb.delete(); channels.delete(); green.delete();
  blurred.delete(); enhanced.delete(); roi.delete(); roiRgb.delete();
  kernel.delete(); noVessels.delete(); discBin.delete(); cupBin.delete();
  resultMat.delete();
  if (dCnt) dCnt.delete();
  if (cCnt) cCnt.delete();

  return result;
}
